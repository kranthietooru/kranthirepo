﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Reflection;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;


namespace UnitTestProject
{
    [TestClass]
    public class UnitTest
    {
        private TestContext m_testContext;

        public TestContext TestContext
        {
            get { return m_testContext; }
            set { m_testContext = value; }
        }
        
        [TestMethod]
        public void TestMethod1()
        {

            try
            {
                string planID = m_testContext.Properties["__Tfs_TestPlanId__"].ToString();
                Console.WriteLine("Test Plan ID -  " + planID);

                string caseID = m_testContext.Properties["__Tfs_TestCaseId__"].ToString();
                Console.WriteLine("Test Case ID -  " + caseID);

                //string pointID = m_testContext.Properties["__Tfs_TestPointId__"].ToString();
                //Console.WriteLine("Test Point ID -  " + pointID);

                string RunId = m_testContext.Properties["__Tfs_TestRunId__"].ToString();
                Console.WriteLine("TestRunId -  " + RunId);

                string codeBase = Assembly.GetExecutingAssembly().CodeBase;
                UriBuilder uri = new UriBuilder(codeBase);
                string path = Uri.UnescapeDataString(uri.Path);
                Console.WriteLine("path: " + path);
                string strpt = Path.GetDirectoryName(path);
                Console.WriteLine("Current working directory path: " + strpt);
                string advocatePath = Path.GetFullPath(Path.Combine(strpt, @"..\..\..\"));
                Console.WriteLine("advocatePath: " + advocatePath);
                string advocateApp = advocatePath + "Scripts\\main.py";
                Console.WriteLine("advocateApp: " + advocateApp);

                string python = @"C:\Program Files (x86)\Microsoft Visual Studio\Shared\Python36_64\python.exe";

                string advocateParam = String.Format("{0},{1},{2},{3}", planID, caseID, RunId, advocatePath);

                Console.WriteLine("advocateParam: " + advocateParam);

                Console.WriteLine("-----------------------------------------------");
                
                ProcessStartInfo start = new ProcessStartInfo();
                start.FileName = python;
                start.Arguments = advocateApp + " " + advocateParam;
                start.UseShellExecute = false;
                start.CreateNoWindow = true;
                start.RedirectStandardOutput = true;
                start.RedirectStandardError = true;
                using (Process process = Process.Start(start))
                {
                    using (StreamReader reader = process.StandardOutput)
                    {
                        string output = reader.ReadToEnd();
                        Console.WriteLine(output.ToString());
                        if ( output.Contains("FAIL") || output.Contains("error"))
                        {
                            Exception ex = new Exception();
                            throw ex;
                        }

                        //Console.WriteLine("jstdout end");
                        string stderr = process.StandardError.ReadToEnd();
                        Console.WriteLine("stderr : " + stderr.ToString());
                        if (stderr.Contains("Traceback") || stderr.Contains("Fail") || stderr.Contains("Failed"))
                        {
                            Exception ex = new Exception();
                            throw ex;
                        }
                        

                        string result = reader.ReadToEnd(); // Here is the result of StdOut(for example: print "test")
                        Console.WriteLine("result from unit test " + result.ToString());

                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error : " + ex.Message);
                Console.WriteLine("Stacktrace : " + ex.StackTrace.ToString());
                throw ex;
            }
        }
                

        [TestInitialize]
        public void InitializationMethod()
        {
            // TestMethod1();            
        }
    }
}
