from Read_Hive_table import *
from Read_Table import *
from validator import *
from config import *
from Read_Hive_table_Source import *
from SourceConnection import *
from RestRequests import *
import os
import sys

"""
    SourceConnection.execute(())
    This function reads the config file parameters. 
    Based on sourcetype added in config file, tool connects to source and target.
    After loading of source and target data to local dataframes, the data and schema are compared.
    Results are returned back. The generated results are attached back to Testcase as TestResults via restapi calls
    Pass & Fail outcome status is sent to UnitTest Wrapper.
    
"""

class SourceConnection:       
    def execute(self,PlanId,TestcaseId,dir,RunId,file_path,resdict):
        try:      
             ResultColumns = ['FINAL_MESSGAE','RESULT','RESULT_MESSAGE']
             Resultrows=[]
             RESULT_FOLDER_NAME = dir +"\\Scripts"            
             res = ''
             SOURCEREADFLAG = 0
             TARGETREADFLAG = 0
             FINALMESSAGE = None
             TestCaseId = TestcaseId 
             print("Processing Test Case: " + TestCaseId)
             DB_SOURCE_TYPE = resdict['SOURCE_TYPE']
             SOURCE_QUERY = resdict['SOURCE_QUERY']
             TARGET_QUERY = resdict['TARGET_QUERY']  
             SOURCE_COUNT_QUERY = resdict['SOURCE_COUNT_QUERY']
             TARGET_COUNT_QUERY = resdict['TARGET_COUNT_QUERY']                      
             
             if(DB_SOURCE_TYPE == 'NETEZZA_ADS'):
                 Sourcedata = Readtable.from_netezza_ads('self',file_path,source_query=SOURCE_QUERY,source_count_query=SOURCE_COUNT_QUERY)
                 Mysourcedata = Sourcedata[0]
                 sourcecount = Sourcedata[1] 
                 FINALMESSAGE = 'Source table records loaded successfully'
                 print(FINALMESSAGE)
                 SOURCEREADFLAG = 2
             elif(DB_SOURCE_TYPE == 'NETEZZA_ZEAMST'):
                Sourcedata = Readtable.from_netezza_mstdb('self',file_path,source_query=SOURCE_QUERY,source_count_query=SOURCE_COUNT_QUERY)
                Mysourcedata = Sourcedata[0]
                sourcecount = Sourcedata[1]                    
                #print(Mysourcedata[0])
                FINALMESSAGE = 'Source table records loaded successfully'
                print(FINALMESSAGE)
                SOURCEREADFLAG = 2
             elif(DB_SOURCE_TYPE == 'NETEZZA_PMLHVADSDB'):
                Sourcedata = Readtable.from_netezza_PMLHVADSDB('self',file_path,source_query=SOURCE_QUERY,source_count_query=SOURCE_COUNT_QUERY)
                Mysourcedata = Sourcedata[0]
                sourcecount = Sourcedata[1]                    
                #print(Mysourcedata[0])
                FINALMESSAGE = 'Source table records loaded successfully'
                print(FINALMESSAGE)
                SOURCEREADFLAG = 2
             elif(DB_SOURCE_TYPE == 'DB2_MDMODS'):
                Sourcedata = Readtable.from_db2_mdmods('self',file_path,source_query=SOURCE_QUERY,source_count_query=SOURCE_COUNT_QUERY)
                Mysourcedata = Sourcedata[0]
                sourcecount = Sourcedata[1]                    
                #print(Mysourcedata[0])
                FINALMESSAGE = 'Source table records loaded successfully'
                print(FINALMESSAGE)
                SOURCEREADFLAG = 2
             elif(DB_SOURCE_TYPE == 'DB2_DMS'):
                Sourcedata = Readtable.from_db2_dms('self',file_path,source_query=SOURCE_QUERY,source_count_query=SOURCE_COUNT_QUERY)
                Mysourcedata = Sourcedata[0]
                sourcecount = Sourcedata[1]                    
                #print(Mysourcedata[0])
                FINALMESSAGE = 'Source table records loaded successfully'
                print(FINALMESSAGE)
                SOURCEREADFLAG = 2
             elif(DB_SOURCE_TYPE == 'MYSQL'):
                Sourcedata = Readtable.from_Mysql('self',file_path,source_query=SOURCE_QUERY,source_count_query=SOURCE_COUNT_QUERY)
                Mysourcedata = Sourcedata[0]
                sourcecount = Sourcedata[1]                    
                #print(Mysourcedata[0])
                FINALMESSAGE = 'Source table records loaded successfully'
                print(FINALMESSAGE)
                SOURCEREADFLAG = 2
             elif(DB_SOURCE_TYPE == 'SQLSERVER_EDB'):
                Sourcedata = Readtable.from_sqlserver_edb('self',file_path,source_query=SOURCE_QUERY,source_count_query=SOURCE_COUNT_QUERY)
                Mysourcedata = Sourcedata[0]
                sourcecount = Sourcedata[1]                    
                #print(Mysourcedata[0])
                FINALMESSAGE = 'Source table records loaded successfully'
                print(FINALMESSAGE)
                SOURCEREADFLAG = 2
             elif(DB_SOURCE_TYPE == 'SQLSERVER_PATH'):
                Sourcedata = Readtable.from_sqlserver_path('self',file_path,source_query=SOURCE_QUERY,source_count_query=SOURCE_COUNT_QUERY)
                Mysourcedata = Sourcedata[0]
                sourcecount = Sourcedata[1]                    
                #print(Mysourcedata[0])
                FINALMESSAGE = 'Source table records loaded successfully'
                print(FINALMESSAGE)
                SOURCEREADFLAG = 2
             elif(DB_SOURCE_TYPE == 'SQLSERVER_RCIS'):
                SourceData = Readtable.from_sqlserver_rcis('self',file_path,source_query=SOURCE_QUERY,source_count_query=SOURCE_COUNT_QUERY)                    
                Mysourcedata = SourceData[0]
                sourcecount = SourceData[1]                             
                #print(Mysourcedata[0])   
                print('Source table records loaded successfully')                        
                Mysourcedata = check_source_hive_results('self',dir)
                SOURCEREADFLAG= 2
             elif(DB_SOURCE_TYPE== 'HIVE'):                    
                SourceData = Readtable.from_hive_source('self',file_path,source_query=SOURCE_QUERY,source_count_query=SOURCE_COUNT_QUERY)                                        
                Mysourcedata = SourceData[0]
                sourcecount = SourceData[1]
                #print(Mysourcedata)                   
                print('Source table records loaded successfully')                    
                Mysourcedata = check_source_hive_results('self',dir)
                SOURCEREADFLAG= 2                    
             else:
                print("Invalid Source type defined int he Table_list.csv file")
                FINALMESSAGE = 'Source_table_read_Failed'
                SOURCEREADFLAG = 0

             TargetData = Readtable.from_hive_target('self',file_path=file_path,target_query = TARGET_QUERY,target_count_query=TARGET_COUNT_QUERY)          
             Myhivedata = TargetData[0]
             targetcount = TargetData[1]
             #if not Myhivedata.empty:
             print('Target table records loaded successfully')                       
             #print(Myhivedata)                     
             Myhivedata = check_hive_results('self',dir)
             TARGETREADFLAG = 1

             if(SOURCEREADFLAG ==2 and TARGETREADFLAG ==1):
                 validater = Ing_Validater_2(Myhivedata, None, Mysourcedata,sourcecount,targetcount)
                 res, mesg = validater.recordcheck(dir,"Source--Target", doExpect=True, isValid=False)
                 print(res)
                 print(mesg)
                 FINALMESSAGE = "Source & Target data validated"
                 #print(FINALMESSAGE)
                 with open(file_path, "a") as logfile:
                     logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + str(mesg))
                     #logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + str(FINALMESSAGE))
                     logfile.close()
                 Resultrow = [FINALMESSAGE,res,mesg]
                 Resultrows.append(Resultrow)                    
             else:
                 print("Source or Target was not loaded properly Hence Validator was not executed")

             Resultdf = pd.DataFrame(Resultrows,columns=ResultColumns)
             if(res != 'HiveFailed'): #Condition to check if hive envt is down
                  Resultdf.to_csv(RESULT_FOLDER_NAME+'\\'+RESULT_FILE_NAME, mode='w', header=True, sep='|')
             ResultId = str(rest_requests.get_resultID('self',RunId,TestcaseId))
             print("ResultId :  " + ResultId)
             with open(file_path, "a") as logfile:
                  logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + ":: ResultId :  " + ResultId)
                  logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + ":: Result :  " + res)
                  logfile.close()
             if(ResultId != '' and res == 'P'): 
                if(RunId != ""): 
                    with open(file_path, "a") as logfile:                    
                        logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + ":: Testcase Passed ")
                        logfile.close()
                    resultFile = rest_requests.post('self',RESULT_FOLDER_NAME+RESULT_FILE_NAME,ResultFileName,"Result File uploaded",RunId,ResultId)
                    sqldatafile = rest_requests.post('self',RESULT_FOLDER_NAME+SQLDATA_FILE_NAME,SqlDataFileName,"SQL Data File uploaded",RunId,ResultId)
                    #stdoutfile = rest_requests.post('self',RESULT_FOLDER_NAME+STDOUT_File_NAME,StdOutFileName,"StdOut File uploaded",RunId,ResultId)
                    blobdtfile = rest_requests.post('self',RESULT_FOLDER_NAME+BLOBDT_FILENAME,"blobdt.csv","Blobdt File uploaded",RunId,ResultId)
                    with open(file_path, "a") as logfile:
                        logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + ":: Attachments Uploaded ")
                        logfile.close()                        
                    Readtable.deletefiles('self',dir +"\\Scripts")
                else:
                      print("Error fetching RunId")
             else:                
                if(RunId != "" and res == 'F'):   
                    #with open(file_path, "a") as logfile:
                    #    logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + ":: Testcase Failed ")
                    #    logfile.close()
                    resultFile = rest_requests.post('self',RESULT_FOLDER_NAME+RESULT_FILE_NAME,ResultFileName,"Result File uploaded",RunId,ResultId)
                    sqldatafile = rest_requests.post('self',RESULT_FOLDER_NAME+SQLDATA_FILE_NAME,SqlDataFileName,"SQL Data File uploaded",RunId,ResultId)
                    #stdoutfile = rest_requests.post('self',RESULT_FOLDER_NAME+STDOUT_File_NAME,StdOutFileName,"StdOut File uploaded",RunId,ResultId)
                    blobdtfile = rest_requests.post('self',RESULT_FOLDER_NAME+BLOBDT_FILENAME,"blobdt.csv","Blobdt File uploaded",RunId,ResultId)
                    with open(file_path, "a") as logfile:
                        logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + ":: Attachments Uploaded ")
                        logfile.close()
                    Readtable.deletefiles('self',dir +"\\Scripts")
                else:
                    if(res == 'HiveFailed' and RunId != ""):
                        resultFile = rest_requests.post('self',RESULT_FOLDER_NAME+RESULT_FILE_NAME,ResultFileName,"Result File uploaded",RunId,ResultId)
                    else:
                        print("Error fetching RunId")
             
        except Exception as error: 
            print("Exception occured")