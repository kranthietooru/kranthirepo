'''
    Readtable class
    This class has the list of function written to connect to respective sources of data and load in dataframes
    This file contains all classes and methods needed to connect and read Azure SQL
    libraries for reading sql""" # will add differnet sources when needed
'''

import codecs
import json
import pandas.io.sql
import pyodbc
import pymysql
import pymysql.cursors
import ibm_db_dbi as db2
import numpy as np
import os
from config import *


# Class for reading tables.
class Readtable:   

    def from_Mysql(self,file_path, source_query,source_count_query):
        # Create the connection for Mysql
        Mysqlconn = pymysql.connect(host=config.MY_SQL_SERVER,
                             user=config.MY_SQL_USERNAME,
                             password= config.MY_SQL_PASSWORD,
                             db=config.MY_SQL_DATABASE,
                             charset=config.MY_SQL_CHARACTERSET,
                             cursorclass=pymysql.cursors.DictCursor)
        hivedf = pandas.read_sql(source_count_query, sqlserverconn)                        
        cnt = hivedf.values.T.tolist()[0][0]
                
        Mysqldf = pandas.read_sql(source_query, Mysqlconn)
        df.rename(columns=lambda x:x.upper(),inplace=True)
        Mysqlconn.close()
        return Mysqldf,cnt

    def from_sqlserver_edb(self, file_path, source_query,source_count_query):
        sqlserverconn = pyodbc.connect('DRIVER=' + SQLSERVER_EDB_DRIVER + ';SERVER=' + SQLSERVER_EDB_SERVER + ';PORT=1443;DATABASE=' + SQLSERVER_EDB_DATABASE + ';UID=' + SQLSERVER_EDB_USERNAME + ';PWD=' +SQLSERVER_EDB_PASSWORD)
        hivedf = pandas.read_sql(source_count_query, sqlserverconn)                        
        cnt = hivedf.values.T.tolist()[0][0]

        sqlserverdf = pandas.read_sql(source_query, sqlserverconn)
        sqlserverdf = sqlserverdf.applymap(lambda x: x.strip() if isinstance(x, str) else x)
        sqlserverdf = sqlserverdf.applymap(lambda x: str(x).split(".")[0] if isinstance(x,object)  else x)
        sqlserverconn.close()
        return sqlserverdf,cnt

    def from_sqlserver_path(self, file_path, source_query,source_count_query):
        sqlserverconn = pyodbc.connect('DRIVER=' + SQLSERVER_PATH_DRIVER + ';SERVER=' + SQLSERVER_PATH_SERVER + ';PORT=1443;DATABASE=' + SQLSERVER_PATH_DATABASE + ';UID=' + SQLSERVER_PATH_USERNAME + ';PWD=' +SQLSERVER_PATH_PASSWORD)
        
        hivedf = pandas.read_sql(source_count_query, sqlserverconn)                        
        cnt = hivedf.values.T.tolist()[0][0]
        
        sqlserverdf = pandas.read_sql(source_query, sqlserverconn)
        sqlserverdf = sqlserverdf.applymap(lambda x: x.strip() if isinstance(x, str) else x)
        sqlserverdf = sqlserverdf.applymap(lambda x: str(x).split(".")[0] if isinstance(x,object)  else x)
        sqlserverconn.close()
        return sqlserverdf,cnt
        

    def from_netezza_ads(self,file_path, source_query,source_count_query):
        netezzaconn = pyodbc.connect('DRIVER='+ NETEZZA_ADS_DRIVER+';SERVER='+ NETEZZA_ADS_SERVER+';PORT='+NETEZZA_ADS_PORT+'+;DATABASE='+NETEZZA_ADS_DATABAE+';UID='+ NETEZZA_ADS_USERNAME+';PWD='+ NETEZZA_ADS_PASSWORD+';')

        hivedf = pandas.read_sql(source_count_query, netezzaconn)                        
        cnt = hivedf.values.T.tolist()[0][0]
                
        netezzadf = pandas.read_sql(source_query,netezzaconn)
        netezzadf = netezzadf.applymap(lambda x: x.strip() if isinstance(x, str) else x)
        netezzadf = netezzadf.applymap(lambda x: str(x).split(".")[0] if isinstance(x,object)  else x)
        netezzaconn.close()
        return netezzadf,cnt

    def from_netezza_mstdb(self,file_path, source_query,source_count_query):
        try:
            SOURCELOCALFILENAME = "/".join(os.getcwd().strip("/").split('/')[:3]) +'\Scripts\source'
            cnt = Readtable.getMSTDBCount(self,source_count_query,file_path)
            netezzaconn = pyodbc.connect('DRIVER='+ NETEZZA_MSTDB_DRIVER+';SERVER='+ NETEZZA_MSTDB_SERVER+';PORT='+NETEZZA_MSTDB_PORT+'+;DATABASE='+NETEZZA_MSTDB_DATABAE+';UID='+ NETEZZA_MSTDB_USERNAME+';PWD='+ NETEZZA_MSTDB_PASSWORD+';')
            #netezzasql = "SELECT * FROM {0}.{1} WHERE {2}".format(db_schema_name,db_table_name,where_clause)
            netezzadf = pandas.read_sql(source_query,netezzaconn)
            netezzadf = netezzadf.applymap(lambda x: x.strip() if isinstance(x, str) else x)
            netezzadf = netezzadf.applymap(lambda x: str(x).split(".")[0] if isinstance(x,object)  else x)
            netezzadf.to_csv(SOURCELOCALFILENAME, mode='w', header=True, sep='\t', index=False)
            netezzaconn.close()
            return netezzadf,cnt
        except Exception as error:            
            print("Exception occured")            
            print('Caught this error: ' + repr(error)) 

    def from_netezza_PMLHVADSDB(self,file_path, source_query,source_count_query):
        netezzaconn = pyodbc.connect('DRIVER='+ NETEZZA_PMLHVADSDB_DRIVER+';SERVER='+ NETEZZA_PMLHVADSDB_SERVER+';PORT='+NETEZZA_PMLHVADSDB_PORT+'+;DATABASE='+NETEZZA_PMLHVADSDB_DATABAE+';UID='+ NETEZZA_PMLHVADSDB_USERNAME+';PWD='+ NETEZZA_PMLHVADSDB_PASSWORD+';')

        hivedf = pandas.read_sql(source_count_query, netezzaconn)                        
        cnt = hivedf.values.T.tolist()[0][0]
                
        netezzadf = pandas.read_sql(source_query,netezzaconn)
        netezzadf = netezzadf.applymap(lambda x: x.strip() if isinstance(x, str) else x)
        netezzadf = netezzadf.applymap(lambda x: str(x).split(".")[0] if isinstance(x,object)  else x)
        netezzaconn.close()
        return netezzadf,cnt

    def from_db2_mdmods(self,file_path, source_query,source_count_query):
        db2conn = db2.connect("DATABASE=EIDMODSQ;HOSTNAME=10.148.213.61;PORT=60134;PROTOCOL=TCPIP;UID=INFAQADM;PWD=C3XKt8D67;", "", "")

        hivedf = pandas.read_sql(source_count_query, db2conn)                        
        cnt = hivedf.values.T.tolist()[0][0]
        
        db2df = pandas.read_sql(source_query,db2conn)
        db2conn.close()
        return db2df,cnt

    def from_db2_dms(self,file_path, source_query,source_count_query):
        db2conn = db2.connect("DATABASE=db2t;HOSTNAME=10.148.133.87;PORT=50000;PROTOCOL=TCPIP;UID=cosdb2t;PWD=T2PIDCOS;", "", "")

        hivedf = pandas.read_sql(source_count_query, db2conn)                        
        cnt = hivedf.values.T.tolist()[0][0]
               
        db2df = pandas.read_sql(source_query,db2conn)
        db2df = db2df.applymap(lambda x: x.strip() if isinstance(x, str) else x)
        db2df = db2df.applymap(lambda x: str(x).split(".")[0] if isinstance(x,object)  else x)
        db2conn.close()
        return db2df,cnt

    def from_sqlserver_mstdb(self, file_path, source_query,source_count_query):
        try:            
            #sqlserverconn = pyodbc.connect('DRIVER=' + SQLSERVER_MSTDB_DRIVER + ';SERVER=' + SQLSERVER_MSTDB_SERVER + ';PORT=1443;DATABASE=' + SQLSERVER_MSTDB_DATABASE + ';UID=' + SQLSERVER_MSTDB_USERNAME + ';PWD=' +SQLSERVER_MSTDB_PASSWORD + ';Encrypt=Yes;TrustServerCertificate=no;Connection Timeout=30')
            sqlserverconn = pyodbc.connect('Driver={ODBC Driver 13 for SQL Server};Server=tcp:datsqlsv01hub01dv01.database.windows.net,1433;Database=datsqldw01hub01dv01;Uid=sqladmin@datsqlsv01hub01dv01;Pwd=sqSv1@Hub01!;Encrypt=yes;TrustServerCertificate=no;Connection Timeout=30');

            hivedf = pandas.read_sql(source_count_query, sqlserverconn)                        
            cnt = hivedf.values.T.tolist()[0][0]
                        
            sqlserverdf = pandas.read_sql(source_query, sqlserverconn)
            sqlserverdf = sqlserverdf.applymap(lambda x: x.strip() if isinstance(x, str) else x)
            sqlserverdf = sqlserverdf.applymap(lambda x: str(x).split(".")[0] if isinstance(x,object)  else x)            
            sqlserverconn.close()
            return sqlserverdf,cnt
        except Exception as error:
            #with open(file_path, "a") as logfile:
            #    logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + 'Caught this error: ' + str(error))
            #    logfile.close()
            print("Exception occured in Readtable.from_sqlserver_mstdb")            
            print('Caught this error: ' + str(error))

    def from_sqlserver_rcis(self,file_path, source_query,source_count_query):
        try:
            sqlserverconn = pyodbc.connect('DRIVER=' + SQLSERVER_RCIS_DRIVER + ';SERVER=' + SQLSERVER_RCIS_SERVER + ';PORT=1443;DATABASE=' + SQLSERVER_RCIS_DATABASE + ';UID=' + SQLSERVER_RCIS_USERNAME + ';PWD=' +SQLSERVER_RCIS_PASSWORD)
                                  
            hivedf = pandas.read_sql(source_count_query, sqlserverconn)                        
            cnt = hivedf.values.T.tolist()[0][0]

            sqlserverdf = pandas.read_sql(source_query, sqlserverconn)
            sqlserverdf = sqlserverdf.applymap(lambda x: x.strip() if isinstance(x, str) else x)
            sqlserverdf = sqlserverdf.applymap(lambda x: str(x).split(".")[0] if isinstance(x,object)  else x)
            sqlserverdf.rename(columns=lambda x:x.upper(),inplace=True)            
            sqlserverconn.close()        
            return sqlserverdf,cnt
        except Exception as error:
            #with open(file_path, "a") as logfile:
            #    logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + 'Caught this error: ' + str(error))
            #    logfile.close()
            print("Exception occured in Readtable.from_sqlserver_rcis")            
            print('Caught this error: ' + str(error))
    
    def from_hive_source(self,file_path, source_query,source_count_query):
        try:
            SOURCELOCALFILENAME = "/".join(os.getcwd().strip("/").split('/')[:3]) +'\Scripts\source'
            #hiveconn = pyodbc.connect("DSN=MyAzureDatabricks_DSN",autocommit = True)  # TO CONNECT TO Dev Environment
            cnt = Readtable.getCount(self,source_count_query,DSN_SOURCE,file_path)           

            hiveconn = pyodbc.connect('DSN='+ DSN_SOURCE,autocommit = True)            
            #hiveconn = pyodbc.connect('DRIVER={Microsoft Spark ODBC Driver};Host=centralus.azuredatabricks.net;PORT=443;HTTPPath=sql/protocolv1/o/3436246995754965/0426-152300-mossy391;UID=token;PWD=dapiedc8169970d98d50c253eeeda695bd9d;AuthMech=3;SSL=1;transportMode=http;LogLevel=6;', autocommit=True)                   
            hivedf = pandas.read_sql(source_query, hiveconn)    
            hivedf = hivedf.applymap(lambda x: x.strip() if isinstance(x, str) else x)
            hivedf = hivedf.applymap(lambda x: str(x).split(".")[0] if isinstance(x,object)  else x)
            hivedf.to_csv(SOURCELOCALFILENAME, mode='w', header=True, sep='\t', index=False)
            #cnt = Readtable.get_table_count(self,source_query,DSN_SOURCE,file_path,query_type) 
            
            #write hivedf data to blobdt file            
            return hivedf,cnt
        except Exception as error:
            print("Exception occured in Readtable.from_hive_source")               
            print('Caught this error: ' + str(error))

    def from_hive_target(self,file_path, target_query,target_count_query):
        try:
            LOCALFILENAME = "/".join(os.getcwd().strip("/").split('/')[:3]) + '\Scripts\stdout'
            cnt = Readtable.getCount(self,target_count_query,DSN_TARGET,file_path) 
            #sqlserverconn = pyodbc.connect('DRIVER=' + SQLSERVER_MSTDB_DRIVER + ';SERVER=' + SQLSERVER_MSTDB_SERVER + ';PORT=1443;DATABASE=' + SQLSERVER_MSTDB_DATABASE + ';UID=' + SQLSERVER_MSTDB_USERNAME + ';PWD=' +SQLSERVER_MSTDB_PASSWORD + ';Encrypt=Yes;TrustServerCertificate=no;Connection Timeout=30')
            #hiveconn = pyodbc.connect("DSN=MyAzureDatabricks_DSN",autocommit = True)  # TO CONNECT TO Dev Environment
            hiveconn = pyodbc.connect('DSN='+ DSN_TARGET,autocommit = True)             
            hivedf = pandas.read_sql(target_query, hiveconn)
            hivedf = hivedf.applymap(lambda x: x.strip() if isinstance(x, str) else x)
            hivedf = hivedf.applymap(lambda x: str(x).split(".")[0] if isinstance(x,object)  else x)
            hivedf.to_csv(LOCALFILENAME, mode='w', header=True, sep='\t', index=False)
            #cnt = Readtable.get_table_count(self,target_query,DSN_TARGET,file_path,query_type)
            #write hivedf data to blobdt file            
            return hivedf,cnt
        except Exception as error:
            print("Exception occured in Readtable.from_hive_target")            
            print('Caught this error: ' + str(error))

    def getCount(self,selectqry,DSN,file_path):
        try:
            hiveconn = pyodbc.connect('DSN='+ DSN,autocommit = True)   
            hivedf = pandas.read_sql(selectqry, hiveconn)
                        
            return (hivedf.values.T.tolist())[0][0]
        except Exception as error:
            with open(file_path, "a") as logfile:
                logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + 'Caught this error: ' + str(error))
                logfile.close()
            print("Exception occured in Readtable.get_table_count")            
            print('Caught this error: ' + str(error))

    def getMSTDBCount(self,selectqry,file_path):
        try:           
            netezzaconn = pyodbc.connect('DRIVER='+ NETEZZA_MSTDB_DRIVER+';SERVER='+ NETEZZA_MSTDB_SERVER+';PORT='+NETEZZA_MSTDB_PORT+'+;DATABASE='+NETEZZA_MSTDB_DATABAE+';UID='+ NETEZZA_MSTDB_USERNAME+';PWD='+ NETEZZA_MSTDB_PASSWORD+';')            
            netezzadf = pandas.read_sql(selectqry,netezzaconn)
            
            cnt = netezzadf.values.T.tolist()
                        
            return (netezzadf.values.T.tolist())[0][0]
        except Exception as error:
            with open(file_path, "a") as logfile:
                logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + 'Caught this error: ' + str(error))
                logfile.close()
            print("Exception occured in Readtable.get_table_count")            
            print('Caught this error: ' + str(error))

    def get_table_count(self,selectqry,DSN,file_path):
        try:
            hiveconn = pyodbc.connect('DSN='+ DSN,autocommit = True)   
            if(selectqry.find("ORDER") == True):
                qry = selectqry[:selectqry.find('ORDER')]           
            else:
                if('ORDER' in selectqry): 
                    qry = selectqry[:selectqry.find('ORDER')] 
                else:
                    if('order' in selectqry): 
                        qry = selectqry[:selectqry.find('order')] 
                    else:
                        qry = selectqry 

            cnt = ((pandas.read_sql(qry.replace('*','COUNT(*)') , hiveconn))['EXPR_1'].tolist())[0]
        
            return cnt
        except Exception as error:
            with open(file_path, "a") as logfile:
                logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + 'Caught this error: ' + str(error))
                logfile.close()
            print("Exception occured in Readtable.get_table_count")            
            print('Caught this error: ' + str(error))

    def get_table_count_sqlserver(self,sqlserversql):
        try:
            sqlserverconn = pyodbc.connect('DRIVER=' + SQLSERVER_RCIS_DRIVER + ';SERVER=' + SQLSERVER_RCIS_SERVER + ';PORT=1443;DATABASE=' + SQLSERVER_RCIS_DATABASE + ';UID=' + SQLSERVER_RCIS_USERNAME + ';PWD=' +SQLSERVER_RCIS_PASSWORD)
            if(sqlserversql.find("order") == True):
                qry = sqlserversql[:sqlserversql.find('order')]           
            else:
                if(('order' in sqlserversql) or ('ORDER' in sqlserversql)): 
                    qry = sqlserversql[:sqlserversql.find('ORDER')] 
                else:
                    if(('order' in sqlserversql) or ('ORDER' in sqlserversql)): 
                        qry = sqlserversql[:sqlserversql.find('order')] 
                    else:
                        qry = sqlserversql 
                           
            cnt = (pandas.read_sql(qry.replace('TOP 20000 *','COUNT(*)') , sqlserverconn)).values.T.tolist()
            #print(cnt[0][0])        
            return cnt[0][0]
        except Exception as error:            
            print("Exception occured in Readtable.get_table_count_sqlserver")            
            print('Caught this error: ' + str(error))

    def get_netezza_mstdb_tablecount(self,selectqry):
        try:
            hiveconn = pyodbc.connect('DRIVER='+ NETEZZA_MSTDB_DRIVER+';SERVER='+ NETEZZA_MSTDB_SERVER+';PORT='+NETEZZA_MSTDB_PORT+'+;DATABASE='+NETEZZA_MSTDB_DATABAE+';UID='+ NETEZZA_MSTDB_USERNAME+';PWD='+ NETEZZA_MSTDB_PASSWORD+';')  
            if(selectqry.find("ORDER") == True):
                qry = selectqry[:selectqry.find('ORDER')]           
            else:
                if('ORDER' in selectqry): 
                    qry = selectqry[:selectqry.find('ORDER')] 
                else:
                    if('order' in selectqry): 
                        qry = selectqry[:selectqry.find('order')] 
                    else:
                        qry = selectqry 

            cnt = (pandas.read_sql(qry.replace('*','COUNT(*)') , hiveconn)).values.T.tolist()
            
            return cnt[0][0]
        except Exception as error:            
            print("Exception occured in Readtable.get_netezza_mstdb_tablecount")            
            print('Caught this error: ' + str(error))

    def deletefiles(self,dir):
        try:
            os.remove(dir+RESULT_FILE_NAME)
            os.remove(dir+SQLDATA_FILE_NAME)
            os.remove(dir+BLOBDT_FILENAME)
            os.remove(dir+STDOUT_File_NAME)
            sourcefilename = dir+"\\source"
            if os.path.isfile(sourcefilename):
                os.remove(dir+"\\source")
        except Exception as error:            
           print("Exception occured in Readtable.deletefiles")            
           print('Caught this error: ' + str(error))

