import pandas as pd
import base64
import requests
import json
import os
from config import *
from main import *
from RestRequests import *

class rest_requests:
    def post(self,filepath,fileName,Comments,RunId,ResultId):        
        try:
            file = open(filepath, 'rb')
            file_content = file.read()
            base64string = base64.b64encode(file_content).decode('ascii')    
            postRequestStatus = ""
            
            if(requests.get(GetAPI, auth=(RestUserName, RestPassword)).ok):
                  headers  = {"Content-Type": "application/json"}   
                  API_ENDPOINT = "https://znaopshub.visualstudio.com/ZNA%20Cloud%20Datahub/_apis/test/Runs/" + RunId +"/Results/" + ResultId + "/attachments?api-version=5.0-preview.1"                                                                     
                  data2= ('{"stream": "' + base64string + '","fileName": "' + fileName + '","comment": "' + Comments + '","attachmentType": "GeneralAttachment"}')              
                  r = requests.post(url = API_ENDPOINT,auth=(RestUserName, RestPassword), data = data2,headers=headers)                
                  if(r.ok):
                      print(fileName + " Successfully uploaded")
                      postRequestStatus = 1
                  else:
                      "Post request failed while uploading " + fileName + "file."
            else:
                tfsResponse.raise_for_status()
                print("Get request failed")
                postRequestStatus = 0
            
            return postRequestStatus
        except Exception as error:
            print("Exception occured in rest_requests.post")            
            print('Caught this error: ' + repr(error))
    
    def get_resultID(self,RunId,TestCaseId): 
        try:
            ResultId = ""
            restApiCall = "https://znaopshub.visualstudio.com/ZNA%20Cloud%20Datahub/_apis/test/Runs/"+RunId+"/results?api-version=5.0-preview.5"
            r = requests.get(restApiCall, auth=(RestUserName, RestPassword))
            if(r.ok):  
                json_object=  json.loads(r.text) 
                for index in range(len(json_object['value'])):
                    if((json_object['value'][index]['testCase']['id'] == TestCaseId) and (json_object['value'][index]['testRun']['id'] == RunId)):
                        ResultId = json_object['value'][index]['id']
            return ResultId
        except Exception as error:
            print("Exception occured in rest_requests.get_resultID")            
            print('Caught this error: ' + repr(error))
                    
                
    def read_config_file(self,workitemid,dirpath,file_path):
        try:
            res = {} 
            LIST_OF_TABLES_PATH = dirpath
            print("LIST_OF_TABLES_PATH : " + LIST_OF_TABLES_PATH)
            restApiCall = "https://znaopshub.visualstudio.com/ZNA%20Cloud%20Datahub/_apis/wit/workitems/" + workitemid +"?api-version=5.0-preview.3&$expand=all"
            with open(file_path, "a") as logfile:
                logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + ":: Before callng rest call")
                logfile.close()
            r = requests.get(restApiCall, auth=(RestUserName, RestPassword))
            if(r.ok):  
                with open(file_path, "a") as logfile:
                    logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + ":: Inside rest call Ok")
                    logfile.close()
                json_object=  json.loads(r.text)   
                attachmenturl = ""
                for index in range(len(json_object['relations'])):
                    if(json_object['relations'][index]['rel'] == "AttachedFile"):
                        attachmenturl = json_object['relations'][index]['url']              
                print("Config file read")
                with open(file_path, "a") as logfile:
                    logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + ":: Before second rest call")
                    logfile.close()
                r = requests.get(attachmenturl, auth=(RestUserName, RestPassword))
                if(r.ok):
                    with open(file_path, "a") as logfile:
                        logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + ":: Inside second rest call Ok")
                        logfile.close()
                    data = r.text.splitlines(True)
                    listheader = (data[0].replace('\r\n','').split("|"))
                    listcontent = (''.join(map(str, data[1:])).replace('\n','')).split('|')                    
                    for key in listheader: 
                        for value in listcontent: 
                            res[key] = value 
                            listcontent.remove(value) 
                            break                       
                    with open(file_path, "a") as logfile:
                        logfile.write("\n" + str(datetime.datetime.now().strftime("%Y-%m-%d-%H:%M:%S")) + ":: After file write")
                        logfile.close()
                else:
                    print("Failed to connect to rest api to read content of Config file")
            else:
                print("Failed to connect to restapi")
            return res
        except Exception as error:
            print("Exception occured in rest_requests.read_config_file")            
            print('Caught this error: ' + repr(error))