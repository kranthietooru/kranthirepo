'''
    check_source_hive_results
    This function reads source file which contains source data.Source data is loaded in dataframe.
'''

import subprocess, sys
from config import *
from azure.storage.blob import *
import pandas as pd
import datetime


def check_source_hive_results(self,dir):
        SOURCELOCALFILENAME = dir + '\Scripts\source'
        results = None
        try:
            results=pd.read_csv(SOURCELOCALFILENAME, sep="\t",parse_dates=True,infer_datetime_format=True,keep_default_na=False,dtype=str)            
            results.rename(columns = lambda x: x.upper(),inplace=True)                        
            results = results.applymap(lambda x: str(x).split(".")[0] if isinstance(x, object) else x)                        
            #print("Source table records loaded")
        except Exception as error:
            print("Exception occured in Readtable.from_sqlserver_mstdb")            
            print('Caught this error: ' + str(error))
        return results





