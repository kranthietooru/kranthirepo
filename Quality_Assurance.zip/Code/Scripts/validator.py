# -*- coding: utf-8 -*-
"""
This py file contains validation for all tests and include 2 class files:
Ing_Validator - for Ingestion validation

"""
import pandas as pd
from collections import Counter
from Read_Table import *
import datetime

class Ing_Validater_2():
    def __init__(self,blobdata,blobmetadata,sqldata,sourcecount,targetcount):        
        self.blobdata = blobdata
        self.blobmetadata = blobmetadata
        self.sqldata = sqldata
        self.sourcecount = sourcecount
        self.targetcount = targetcount

    def recordcheck(self,dir,str_between,doExpect=True,isValid=False):
        try:
           str_from = str_between.split("--")[0]
           str_to = str_between.split("--")[1]
           
           if self.blobmetadata is not None:
                inds = list(self.blobmetadata[self.blobmetadata.apply(lambda x: min(x) == max(x) == "P", 1)].index) if isValid else list(self.blobmetadata[self.blobmetadata.apply(lambda x: min(x) != max(x) != "P", 1)].index)
                inds = [int(x) - 1 for x in inds]
                nor_csv = len(inds)
           else:
                nor_csv = len(self.blobdata)
                inds = [int(x) for x in range(0,nor_csv)]
           blobdt = self.blobdata.loc[inds]
           #blobdt = blobdt[list(blobdt.columns.values)].astype(str)
           #blobdt = blobdt[list(blobdt.columns.values)[3:]].astype(str)
           blobdt = blobdt[list(blobdt.columns.values)[3:-2]].astype(str)
           blobdt.sort_index(inplace=True)
           nor_sql = len(self.sqldata)
           #self.sqldata =
           #self.sqldata[list(self.sqldata.columns.values)].astype(str)
           #self.sqldata =
           #self.sqldata[list(self.sqldata.columns.values)[3:]].astype(str)
           self.sqldata = self.sqldata[list(self.sqldata.columns.values)[:]].astype(str)
           self.sqldata.to_csv(dir + '\Scripts' + '\sqldata.csv', mode='w', header=True, sep='|')
           blobdt.to_csv(dir + '\Scripts' + '\\blobdt.csv', mode='w', header=True, sep='|')
           flag = ""
           if(self.sourcecount == self.targetcount):
               flag = "P"
           else:
               flag = "F"
           
           merged = blobdt.merge(self.sqldata, left_on=list(blobdt.columns[:]), right_on=list(blobdt.columns[:]),indicator=True, how="left")
           #print(merged)
           #merged.to_csv(RESULT_FOLDER_NAME+'/'+'merged.csv', mode='w',
           #header=True, sep='|')
           dict = Counter(list(merged['_merge']))
           count_both = dict["both"]
           count_left = dict["left_only"]
           if(doExpect):
                if (nor_csv == 0 and nor_sql != 0):
                    if(flag == "P"):
                        mesg1 = "FAIL - %s of the %s do not exist in %s." % (self.sourcecount, str_to, str_from)
                        mesg = "\n\t\n\t# of records in %s = %s\n\t# of records in %s = %s\n\t%s" % (str_from, self.sourcecount, str_to, self.targetcount, mesg1)
                        return "F", mesg
                    else:
                        mesg1 = "\n\tFAIL - Source and Target count mismatch"
                        mesg1 = mesg1 + "\n\tFAIL - %s of the %s do not exist in %s." % (self.sourcecount, str_to, str_from)
                        mesg = "\n\t\n\t# of records in %s = %s\n\t# of records in %s = %s\n\t%s" % (str_from, self.sourcecount, str_to, self.targetcount, mesg1)
                        return "F", mesg
                elif(count_both == nor_csv):
                    if(flag == "P"):
                        mesg1 = "\n\t# of records validated : %s " % (nor_csv)                    
                        mesg1 = mesg1 + "\n\tPASS - The count and data of %s matches with %s." % (str_from,str_to)
                        mesg = "\t# of %s = %s\n\t# of %s = %s \n\t%s" % (str_from,self.sourcecount,str_to,self.targetcount,mesg1)
                        return "P", mesg
                    else:#Msg for count validation failed and data validation
                        mesg1 = "\n\tFAIL - Source and Target count mismatch"
                        mesg1 = mesg1 + "\n\tFAIL - %s of the %s do not exist in %s." % (self.targetcount, str_to, str_from)
                        mesg = "\n\t\n\t# of records in %s = %s\n\t# of records in %s = %s\n\t%s" % (str_from, self.sourcecount, str_to, self.targetcount, mesg1)
                        return "F", mesg
                else:
                    if(nor_csv == nor_sql): #This condition is added to handle duplicates in source & target
                        if(flag == "P"):
                            if(nor_csv == nor_sql and count_both == count_left and flag == "P"):
                                mesg1 = "\n\t# of records validated : %s " % (nor_csv)                    
                                mesg1 = mesg1 + "\n\tPASS - The count and data of %s matches with %s." % (str_from,str_to)
                                mesg = "\t# of %s = %s\n\t# of %s = %s \n\t%s" % (str_from,self.sourcecount,str_to,self.targetcount,mesg1)
                                return "P", mesg
                            else:
                                if(count_both == count_left and flag == "P"):
                                    mesg1 = "\n\t# of records validated : %s " % (nor_csv)                    
                                    mesg1 = mesg1 + "\n\tPASS - The count and data of %s matches with %s." % (str_from,str_to)
                                    mesg = "\t# of %s = %s\n\t# of %s = %s \n\t%s" % (str_from,self.sourcecount,str_to,self.targetcount,mesg1)
                                    return "P", mesg
                                else:
                                    mesg1 = "\n\tSource and Target count matched"
                                    mesg1 = mesg1 + "\n\tFAIL - Source and Target data mismatch"
                                    mesg1 = mesg1 + "\n\tFAIL - %s records of the %s mismatch with %s." % (count_left, str_to, str_from)
                                    mesg = "\n\t\n\t# of records in %s = %s\n\t# of records in %s = %s\n\t%s" % (str_from, self.sourcecount, str_to, self.targetcount, mesg1)
                                    return "F", mesg
                        else:
                            mesg1 = "\n\tFAIL - Source and Target count mismatch"
                            #mesg1 = "FAIL - %s of the %s do not exist
                            #in %s." % (self.targetcount, str_to,
                            #str_from)
                            mesg = "\n\t\n\t# of records in %s = %s\n\t# of records in %s = %s\n\t%s" % (str_from, self.sourcecount, str_to, self.targetcount, mesg1)
                            return "F", mesg
                    else:
                        if(flag == "P"):
                            mesg1 = "\n\tSource and Target count matched"
                            mesg1 = mesg1 + "\n\tFAIL - %s of the %s do not exist in %s." % (count_left,str_from,str_to)
                            ls_temp = [int(x) for x in (merged['_merge'] == "left_only")]
                            ls_leftonly = [i + 1 for i, x in enumerate(ls_temp) if x == 1]
                            mesg = "\t# of %s = %s\n\t# of %s = %s\n\t%s\n\tFAIL-Rows %s in %s do not exist in %s." % (str_from,nor_csv,str_to, nor_sql,mesg1,ls_leftonly,str_from,str_to)
                            return "F", mesg
                        else:
                            mesg1 = "\n\tFAIL - Source and Target count mismatch"
                            #mesg1 = "FAIL - %s of the %s do not exist
                            #in %s."%(count_left,str_from,str_to)
                            ls_temp = [int(x) for x in (merged['_merge'] == "left_only")]
                            ls_leftonly = [i + 1 for i, x in enumerate(ls_temp) if x == 1]
                            mesg = "\t# of %s = %s\n\t# of %s = %s\n\t%s\n\tFAIL-Rows %s in %s do not exist in %s." % (str_from,nor_csv,str_to, nor_sql,mesg1,ls_leftonly,str_from,str_to)
                            return "F", mesg
           else:
                if (nor_csv == 0 and nor_sql != 0):
                    mesg1 = "PASS - None of the records of %s matches with %s." % (str_from, str_to)
                    mesg = "\t\n\t# of records in %s = %s\n\t# of records in %s = %s.\n\t%s" % (str_from, nor_csv, str_to, nor_sql, mesg1)
                    return "P", mesg
                elif (count_left == nor_csv):
                    mesg1 = "PASS - None of the records of %s matches with %s." % (str_from,str_to)
                    mesg = "\t# of %s = %s\n\t# of %s = %s.\n\t%s" % (str_from,nor_csv,str_to, nor_sql,mesg1)
                    return "P", mesg
                else:
                    mesg1 = "FAIL - %s of the %s do exist in %s." % (count_both,str_from,str_to)
                    ls_temp = [int(x) for x in (merged['_merge'] == "both")]
                    ls_both = [i + 1 for i, x in enumerate(ls_temp) if x == 1]
                    mesg = "\t# of %s = %s\n\t# of %s = %s\n\t%s\n\tFAIL-Rows %s in %s do exist in %s." % (str_from,nor_csv,str_to,nor_sql,mesg1,ls_both,str_from,str_to)
                    return "F", mesg
        except Exception as error:
            print("Exception occured in Ing_Validater_2recordcheck")            
            print('Caught this error: ' + str(error))


#Mysqldata = Read_Table.Readtable.from_Mysqlserver('self')
#Myhivedata = Read_Target_Table.Readtargettable.readData_from_hive_CE(DB_TABLE_NAME='RiderMapping')

#validater = Ing_Validater('RiderMapping', Myhivedata, None, Mysqldata)
#res, mesg = validater.recordcheck("records in source Mysql--records in Hive ",doExpect=True,isValid=False)
#print(validater)
#print(res)
#print(mesg)